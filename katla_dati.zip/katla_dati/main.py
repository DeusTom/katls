from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
import time
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import csv



driver = webdriver.Chrome('C:\OneDrive\Desktop\dev\katla_dati\webdriver\chromedriver')
wait = WebDriverWait(driver,15)
driver.get("http://25568651973:0m3MfXZZH7QaBToHF1ek@10.0.0.101/webpages/0/main2.html")



#Get the map where the settings is located
map = driver.find_element_by_xpath('//*[@id="contenedor"]/map/area[1]')

#Get settings coordinates from the map-area attribute
print (map.get_attribute("coords"))
settings = map.get_attribute("coords")

#Split the settings coordinates in x,y,radius
settingsArray = settings.split(",")
print (settingsArray[0], settingsArray[1])

#Locate and click on settings using coordinates found
img = driver.find_element_by_xpath('//*[@id="imagen_fondo"]')
actions = ActionChains(driver)
actions.move_to_element_with_offset(img, settingsArray[0], settingsArray[1])
actions.click()
actions.perform()



tr1Elements = wait.until(EC.visibility_of_all_elements_located((By.XPATH, "//tbody//tr")))

time.sleep(10)

dataList = [[]]
counter = -1
for elm in tr1Elements:
    tdata = elm.find_elements(By.TAG_NAME, "td")
    counter += 1
    dataList.append([])
    for tds in tdata:
        dataList[counter].append(tds.text)
        print (tds.text)

f = open('C:\OneDrive\Desktop\dev\katla_dati\katlaDati.csv', 'w')
writer = csv.writer(f)

for row in dataList:
    writer.writerow(row)


f.close()



time.sleep(2000)



